// Copyright © 2025 Apple Inc. All rights reserved.

import Foundation

/// O(1) dictionary wrapper mapping content hashes to ``CacheBlock`` instances.
///
/// Used by the paged KV cache to detect prefix sharing: when a new sequence
/// produces the same token block as an existing one, the hash map lets us
/// find and reuse the already-computed block instead of recomputing it.
public final class BlockHashMap: @unchecked Sendable {

    // MARK: - Storage

    private var map: [String: CacheBlock] = [:]

    // MARK: - Init

    public init() {}

    // MARK: - API

    /// Insert a block keyed by its ``CacheBlock/blockHash``.
    /// No-op if the block's hash is `nil`.
    public func insert(_ block: CacheBlock) {
        guard let hash = block.blockHash else { return }
        map[hash] = block
    }

    /// Look up a block by its content hash.
    public func find(hash: String) -> CacheBlock? {
        map[hash]
    }

    /// Find the longest stored partial leaf whose tokens are an exact prefix
    /// of the query chunk and whose chained hash belongs to `parentHash`.
    ///
    /// A growing prompt changes the hash of its final, non-block-aligned chunk:
    /// a stored 12-token leaf and a later 39-token query chunk have different
    /// hashes even though the first 12 tokens (and their KV) are identical.
    /// Full blocks continue to use the O(1) exact-hash path; this bounded scan
    /// is reached only after that lookup misses at a partial leaf.
    public func findLongestPartialPrefix(
        parentHash: String?,
        tokenIds: [Int],
        modelKey: String?,
        mediaSalt: String?
    ) -> CacheBlock? {
        var best: CacheBlock?
        for block in map.values {
            let stored = block.tokenIds
            guard !stored.isEmpty,
                  stored.count < block.blockSize,
                  stored.count < tokenIds.count,
                  tokenIds.prefix(stored.count).elementsEqual(stored),
                  block.blockHash == CacheBlock.computeBlockHash(
                      parentHash: parentHash,
                      tokenIds: stored,
                      modelKey: modelKey,
                      mediaSalt: mediaSalt)
            else { continue }

            if best == nil
                || stored.count > best!.tokenCount
                || (stored.count == best!.tokenCount && block.blockId < best!.blockId)
            {
                best = block
            }
        }
        return best
    }

    /// Build once per companion-aware lookup, so a long prefix does not scan
    /// every full KV block again at every position. Entries share immutable
    /// block identity; the owning manager lock protects them during the walk.
    func partialBoundaryCompanionIndex() -> BlockHashMap {
        let partial = BlockHashMap()
        for block in map.values where !block.isEmpty && !block.isFull
            && block.boundaryCompanionData != nil {
            partial.insert(block)
        }
        return partial
    }

    /// Remove the entry for a block (keyed by its ``CacheBlock/blockHash``).
    /// No-op if the block's hash is `nil` or not present.
    public func remove(_ block: CacheBlock) {
        guard let hash = block.blockHash else { return }
        map.removeValue(forKey: hash)
    }

    /// Remove all entries.
    public func removeAll() {
        map.removeAll()
    }

    /// The number of entries currently stored.
    public var count: Int {
        map.count
    }
}
